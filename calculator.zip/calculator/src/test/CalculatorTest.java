import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class CalculatorTest {

    @Test
    public void testAddition() {
        String expression = "4+5";
        String result = Calculator.Run(expression);
        assertEquals("9", result);
    }

    @Test
    public void testSubtraction() {
        String expression = "10-4";
        String result = Calculator.Run(expression);
        assertEquals("6", result);
    }

    @Test
    public void testMultiplication() {
        String expression = "3*4";
        String result = Calculator.Run(expression);
        assertEquals("12", result);
    }

    @Test
    public void testDivision() {
        String expression = "12/4";
        String result = Calculator.Run(expression);
        assertEquals("3", result);
    }

    @Test
    public void testNegativeNumbers() {
        String expression = "-5+3";
        String result = Calculator.Run(expression);
        assertEquals("-2", result);
    }
}